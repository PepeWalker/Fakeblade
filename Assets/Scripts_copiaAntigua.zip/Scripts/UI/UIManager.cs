using UnityEngine;

public class UIManager : MonoBehaviour
{

    public void Initialize() { }
    public void ShowBattleHUD() { }

    public void ShowVictoryScreen(BeyBladeController winner) { }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
