using System.Collections.Generic;
using UnityEngine;

public class BattleManager : MonoBehaviour 
{


    public void StartBattle(List<BeyBladeController> activePlayers) { }

    public void EndBattle() { }



}
